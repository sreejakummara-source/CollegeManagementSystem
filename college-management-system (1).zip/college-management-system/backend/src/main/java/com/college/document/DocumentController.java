package com.college.document;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {
    private final DocumentRepository repository;
    private final Path uploadDir;

    public DocumentController(DocumentRepository repository,
            @Value("${app.upload.dir:uploads}") String directory) throws IOException {
        this.repository = repository;
        this.uploadDir = Paths.get(directory).toAbsolutePath().normalize();
        Files.createDirectories(uploadDir);
    }

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file,
            @RequestParam(value="title", required=false) String title,
            @RequestParam(value="category", required=false) String category) throws IOException {
        if (file.isEmpty()) return ResponseEntity.badRequest().body(Map.of("message", "Please select a file."));
        if (file.getSize() > 10 * 1024 * 1024) return ResponseEntity.badRequest().body(Map.of("message", "Maximum file size is 10 MB."));
        String original = Paths.get(Objects.requireNonNull(file.getOriginalFilename())).getFileName().toString();
        String lower = original.toLowerCase(Locale.ROOT);
        if (!(lower.endsWith(".pdf") || lower.endsWith(".doc") || lower.endsWith(".docx")
                || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png"))) {
            return ResponseEntity.badRequest().body(Map.of("message", "File type not allowed."));
        }
        String stored = UUID.randomUUID() + "_" + original.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path destination = uploadDir.resolve(stored).normalize();
        if (!destination.startsWith(uploadDir)) return ResponseEntity.badRequest().build();
        Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);

        Document doc = new Document();
        doc.setTitle(title == null || title.isBlank() ? original : title.trim());
        doc.setOriginalFilename(original);
        doc.setStoredFilename(stored);
        doc.setContentType(file.getContentType() == null ? "application/octet-stream" : file.getContentType());
        doc.setCategory(category == null || category.isBlank() ? "General" : category);
        doc.setSize(file.getSize());
        return ResponseEntity.ok(repository.save(doc));
    }

    @GetMapping
    public List<Document> list() { return repository.findAll(); }

    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable Long id) throws IOException {
        Document doc = repository.findById(id).orElseThrow();
        Path path = uploadDir.resolve(doc.getStoredFilename()).normalize();
        Resource resource = new UrlResource(path.toUri());
        if (!resource.exists()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(doc.getContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment().filename(doc.getOriginalFilename()).build().toString())
                .body(resource);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws IOException {
        Document doc = repository.findById(id).orElseThrow();
        Files.deleteIfExists(uploadDir.resolve(doc.getStoredFilename()).normalize());
        repository.delete(doc);
        return ResponseEntity.noContent().build();
    }
}
