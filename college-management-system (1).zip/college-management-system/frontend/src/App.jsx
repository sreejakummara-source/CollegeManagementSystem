import React, { useEffect, useState } from 'react';
import { LayoutDashboard, Users, GraduationCap, BookOpen, CalendarCheck, FileText, Upload, Search, Bell, Download, Trash2, Menu, Plus, ArrowUpRight, X } from 'lucide-react';

const API = 'http://localhost:8080/api';
const nav = [
  ['Overview', LayoutDashboard], ['Students', Users], ['Faculty', GraduationCap],
  ['Courses', BookOpen], ['Attendance', CalendarCheck], ['Documents', FileText]
];

export default function App() {
  const [active, setActive] = useState('Overview');
  const [docs, setDocs] = useState([]);
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Academic');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [query, setQuery] = useState('');
  const [mobileNav, setMobileNav] = useState(false);

  async function loadDocs() {
    try { const r = await fetch(`${API}/documents`); if (!r.ok) throw new Error(); setDocs(await r.json()); }
    catch { setNotice('Cannot reach backend. Start Spring Boot on port 8080 and check your MySQL settings.'); }
  }
  useEffect(() => { loadDocs(); }, []);

  async function upload(e) {
    e.preventDefault();
    if (!file) { setNotice('Choose a document first.'); return; }
    const data = new FormData(); data.append('file', file); data.append('title', title); data.append('category', category);
    setBusy(true); setNotice('');
    try {
      const r = await fetch(`${API}/documents/upload`, { method: 'POST', body: data });
      const result = await r.json();
      if (!r.ok) throw new Error(result.message || 'Upload failed.');
      setNotice('Document uploaded successfully.'); setFile(null); setTitle(''); e.target.reset(); await loadDocs();
    } catch (err) { setNotice(err.message || 'Upload failed.'); }
    finally { setBusy(false); }
  }
  async function remove(id) {
    if (!confirm('Delete this document?')) return;
    try { const r = await fetch(`${API}/documents/${id}`, { method: 'DELETE' }); if (!r.ok) throw new Error(); await loadDocs(); setNotice('Document deleted.'); }
    catch { setNotice('Could not delete document.'); }
  }
  const filtered = docs.filter(d => `${d.title} ${d.originalFilename} ${d.category}`.toLowerCase().includes(query.toLowerCase()));
  const totalSize = (docs.reduce((n,d)=>n+d.size,0)/1024/1024).toFixed(1);

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'open':''}`}>
      <div className="brand"><div className="brand-mark"><GraduationCap size={22}/></div><div><b>CampusFlow</b><small>COLLEGE PORTAL</small></div><button className="close-nav" onClick={()=>setMobileNav(false)}><X/></button></div>
      <div className="nav-label">WORKSPACE</div>
      {nav.map(([name, Icon])=><button key={name} className={`nav-item ${active===name?'selected':''}`} onClick={()=>{setActive(name);setMobileNav(false)}}><Icon size={18}/><span>{name}</span>{name==='Documents'&&<span className="nav-count">{docs.length}</span>}</button>)}
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon">✦</div><b>Need a hand?</b><p>Check the project guide for setup and API details.</p><a href="https://spring.io/projects/spring-boot" target="_blank" rel="noreferrer">Explore Spring Boot ↗</a></div><div className="profile"><div className="avatar">AD</div><div><b>Administrator</b><small>College Admin</small></div><span className="online-dot"/></div></div>
    </aside>
    {mobileNav&&<div className="scrim" onClick={()=>setMobileNav(false)}/>}
    <main className="main">
      <header className="topbar"><button className="menu-btn" onClick={()=>setMobileNav(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{active}</b></div><div className="top-actions"><span className="semester">Academic year 2025–26</span><button className="icon-btn"><Bell size={18}/><i/></button><div className="avatar small">AD</div></div></header>
      <section className="content">
        <div className="welcome-row"><div><div className="eyebrow">SATURDAY, NOVEMBER 21, 2026</div><h1>{active==='Overview'?'Good afternoon, Admin':active}</h1><p>{active==='Overview'?'Here’s what’s happening across your campus today.':active==='Documents'?'Store, organize and access your college documents.':`Manage your college ${active.toLowerCase()} in one place.`}</p></div><button className="primary-btn" onClick={()=>setActive('Documents')}><Plus size={17}/> Upload document</button></div>
        {active==='Overview' ? <>
          <div className="stats-grid">
            <Stat icon={Users} label="Total students" value="1,248" delta="+8.2%" color="blue"/>
            <Stat icon={GraduationCap} label="Faculty members" value="86" delta="+2 this term" color="violet"/>
            <Stat icon={BookOpen} label="Active courses" value="32" delta="Across 6 departments" color="orange"/>
            <Stat icon={CalendarCheck} label="Attendance today" value="94.6%" delta="+1.4% this week" color="green"/>
          </div>
          <div className="dashboard-grid">
            <div className="panel activity-panel"><div className="panel-heading"><div><h3>Recent documents</h3><p>Your latest uploaded files</p></div><button className="text-btn" onClick={()=>setActive('Documents')}>View all <ArrowUpRight size={15}/></button></div>
              {docs.length===0?<div className="empty-mini"><FileText size={25}/><b>No documents yet</b><span>Upload your first college document.</span></div>:docs.slice(-4).reverse().map(d=><DocRow key={d.id} doc={d}/>)}
            </div>
            <div className="panel quick-panel"><div className="panel-heading"><div><h3>Quick actions</h3><p>Common admin tasks</p></div></div>
              {[['Upload a document','Add academic files and records',Upload],['Manage students','Review student information',Users],['View attendance','Check class attendance',CalendarCheck]].map(([a,b,I])=><button className="quick-action" key={a} onClick={()=>setActive(a.includes('document')?'Documents':a.includes('students')?'Students':'Attendance')}><span className="quick-icon"><I size={18}/></span><span><b>{a}</b><small>{b}</small></span><ArrowUpRight size={16}/></button>)}
            </div>
          </div>
        </>: active==='Documents'?<>
          <div className="stats-grid doc-stats"><Stat icon={FileText} label="Total documents" value={docs.length} delta="Saved in your library" color="blue"/><Stat icon={Upload} label="Storage used" value={`${totalSize} MB`} delta="Local uploads folder" color="green"/><Stat icon={BookOpen} label="Categories" value={new Set(docs.map(d=>d.category)).size} delta="Document groups" color="violet"/></div>
          <div className="document-layout">
            <div className="panel upload-panel"><div className="panel-heading"><div><h3>Upload a document</h3><p>Add a file to your college library</p></div><span className="upload-symbol"><Upload size={19}/></span></div>
              <form onSubmit={upload}>
                <label className="field-label">Document title</label><input className="field" value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Semester 1 timetable"/>
                <label className="field-label">Category</label><select className="field" value={category} onChange={e=>setCategory(e.target.value)}><option>Academic</option><option>Student Records</option><option>Faculty</option><option>Examination</option><option>Administrative</option><option>General</option></select>
                <label className="field-label">Choose file</label><label className="dropzone"><input type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" onChange={e=>setFile(e.target.files[0])}/><span className="cloud-icon"><Upload size={22}/></span><b>{file?file.name:'Click to browse or drag a file here'}</b><small>PDF, DOC, DOCX, JPG or PNG · Max 10 MB</small></label>
                <button className="primary-btn full" disabled={busy}>{busy?'Uploading…':<><Upload size={17}/> Upload document</>}</button>
              </form>
              {notice&&<div className={`notice ${notice.includes('success')||notice.includes('deleted')?'success':''}`}>{notice}</div>}
            </div>
            <div className="panel library-panel"><div className="panel-heading"><div><h3>Document library</h3><p>{docs.length} files in your collection</p></div><span className="library-count">{docs.length} files</span></div>
              <div className="searchbox"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search documents…"/></div>
              <div className="doc-list">{filtered.length===0?<div className="empty-mini"><FileText size={26}/><b>{docs.length?'No matching documents':'Your library is empty'}</b><span>Uploaded files will appear here.</span></div>:filtered.slice().reverse().map(d=><div className="doc-item" key={d.id}><div className="file-icon"><FileText size={19}/></div><div className="doc-info"><b>{d.title}</b><small>{d.originalFilename} · {(d.size/1024).toFixed(0)} KB</small><span className="category-tag">{d.category||'General'}</span></div><div className="doc-actions"><a title="Download" href={`${API}/documents/${d.id}/download`}><Download size={17}/></a><button title="Delete" onClick={()=>remove(d.id)}><Trash2 size={17}/></button></div></div>)}</div>
            </div>
          </div>
        </>:<div className="panel coming-panel"><div className="coming-icon"><GraduationCap size={28}/></div><h2>{active} module</h2><p>This section is reserved for the next development phase of your College Management System.</p><button className="primary-btn" onClick={()=>setActive('Documents')}>Go to document management</button></div>}
        <footer>© 2026 CampusFlow College Management System <span>Built with React + Spring Boot</span></footer>
      </section>
    </main>
  </div>;
}

function Stat({icon:Icon,label,value,delta,color}) { return <div className="stat-card"><div className={`stat-icon ${color}`}><Icon size={19}/></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-delta">{delta}</div></div>; }
function DocRow({doc}) { return <div className="recent-row"><div className="file-icon"><FileText size={18}/></div><div className="doc-info"><b>{doc.title}</b><small>{doc.category} · {(doc.size/1024).toFixed(0)} KB</small></div><a href={`${API}/documents/${doc.id}/download`}><Download size={17}/></a></div>; }
