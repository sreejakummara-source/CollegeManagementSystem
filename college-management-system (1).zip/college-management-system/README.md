# College Management System

A starter full-stack college management system using React, Java Spring Boot, and MySQL.
Includes a working document upload/list/download/delete module.

## Requirements
- Java 17+
- Maven 3.9+
- Node.js 18+
- MySQL 8+

## 1. Database
Create a database:
```sql
CREATE DATABASE college_management;
```

## 2. Backend
Edit `backend/src/main/resources/application.properties` with your MySQL username/password.
From `backend/` run:
```bash
mvn spring-boot:run
```
Backend: http://localhost:8080

Uploaded files are stored in `backend/uploads/`. File metadata is stored in MySQL.
Allowed upload types: PDF, DOC, DOCX, JPG, JPEG, PNG. Maximum size: 10 MB.

## 3. Frontend
From `frontend/` run:
```bash
npm install
npm run dev
```
Open the URL printed by Vite (usually http://localhost:5173).

## API
- `POST /api/documents/upload` — multipart field `file`, optional `title`, optional `category`
- `GET /api/documents` — list uploaded documents
- `GET /api/documents/{id}/download` — download a document
- `DELETE /api/documents/{id}` — delete a document

## Architecture
```mermaid
flowchart LR
  U[Admin / Student] --> R[React Frontend]
  R -->|REST / JSON + multipart| S[Spring Boot REST API]
  S --> J[Spring Data JPA]
  J --> DB[(MySQL Database)]
  S --> FS[(Uploads Folder)]
```

## Notes for college submission
This is a project starter, not a production-ready student information system. Add authentication/role-based access, validation, audit logs, backups, and malware scanning before real deployment. Do not upload sensitive student records to a public server without appropriate security and consent.
